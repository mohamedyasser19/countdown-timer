let timerInterval;
let timeInSeconds;
let paused = false;

function startTimer() {
  const hours = parseInt(document.getElementById('hours').value) || 0;
  const minutes = parseInt(document.getElementById('minutes').value) || 0;
  const seconds = parseInt(document.getElementById('seconds').value) || 0;

  timeInSeconds = hours * 3600 + minutes * 60 + seconds;

  if (isNaN(timeInSeconds) || timeInSeconds <= 0) {
    alert('Please enter a valid positive number for the time.');
    return;
  }

  stopTimer();
  updateTimer();
  timerInterval = setInterval(() => updateTimer(), 1000);
  paused = false;
}

function stopTimer() {
  clearInterval(timerInterval);
  paused = true;
}

function continueTimer() {
  if (paused) {
    timerInterval = setInterval(() => updateTimer(), 1000);
    paused = false;
  }
}

function restartTimer() {
  stopTimer();
  startTimer();
}

function resetTimer() {
  stopTimer();
  timeInSeconds = 0;
  updateTimer();
}

function updateTimer() {
  const hours = Math.floor(timeInSeconds / 3600);
  const minutes = Math.floor((timeInSeconds % 3600) / 60);
  const seconds = timeInSeconds % 60;

  const formattedTime = `${formatTime(hours)}:${formatTime(minutes)}:${formatTime(seconds)}`;

  document.getElementById('timer').innerText = formattedTime;

  if (timeInSeconds > 0) {
    timeInSeconds--;
  } else {
    stopTimer();
  }
}

function formatTime(time) {
  return time < 10 ? `0${time}` : time;
}
 